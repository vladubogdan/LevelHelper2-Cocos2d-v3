//
//  LHRotationProperty.h
//  LevelHelper2-SpriteKit
//
//  Created by Bogdan Vladu on 22/04/14.
//  Copyright (c) 2014 GameDevHelper.com. All rights reserved.
//

#import "LHAnimationProperty.h"

@interface LHRotationProperty : LHAnimationProperty

@end
